This is a simple GUI on a FreeBasic graphics window. GUI.bas is a source library which can be used as include file. The following controls (GUI elements) are implemented in GUI.bas:

- Label
- Textbox
- Button
- Checkbox
- Radiobutton
- Listbox
- DataGrid (editable)
- Trackbar
- Progressbar
- Panel (can be used as a subwindow, is used by inputbox and messagebox) 
- Inputbox
- Messagebox

The other files are used to test GUI.bas and can be used as simple examples how to create GUI applications.

The color scheme for the GUI is defined by color constants at the top of GUI.bas. These constants can be changed by the user.

Textboxes and inputboxes can be used to enter strings, passwords (only asterisks will be displayed) or numeric values (only digits will be accepted). 

The contents of the listbox can be scrolled vertically by means of the mousewheel or by means of the symbols "up" and "down" at the top and bottom of the sidebar. Therefore it is necessary to include "ListBox_Event" in the event loop, see Prime_Numbers.bas! The buffersize of the listbox (= highest index, beginning from 0) is limited to 1000, see constant "BufSize" at the top of GUI.bas. This constant can be changed by the user.

In order to keep the GUI fast, events of all controls are requested using "GetMouse" without additional delay 
("Sleep 1"). It is therefore recommended to include "Sleep 1" once into the event loop in the main program instead.

July 09, 2015
Lothar Schirm
