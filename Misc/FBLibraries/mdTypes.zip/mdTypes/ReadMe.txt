mdTypes - by MOD

mdTypes is a collection of FreeBASIC classes which are based on Java classes.
If these classes are generic in Java, the FreeBASIC class will use macros to allow some kind of generics, too.

Installation:
Copy "md/" folder to FreeBASICs "inc/" folder and start using it.

Usage:
See Java classes for documentation. You will find a link at the top of each mdTypes-file.
