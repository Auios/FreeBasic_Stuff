Example mini-game created for the purpose of a tutorial.
DON'T REVIEW IT!

Only "Sheep Massacre" is implemented.

CONTROLS:
ARROW KEYS - move the warrior
SPACE - swing the sword
ENTER - shoot the fireball(only one can be on the screen)

GOAL:
Kill all the sheep in least amount of time.


*** Lachie Dazdarian, September 2011 (FB ver.0.23 rewrite!)
