===============================================================================
================Pixel by pixel scrolling engine by R. Eric Lope================
===============================**FreeBASIC PORT**==============================
==============================Edition #3, Jan 2008.============================
===============================================================================

Original engine code: Richard Eric Lope
Tiles and sprites: Ingmar v.d. Steen and Lachie Dazdarian
Custom font: Lachie Dazdarian
Additional code and packing: Lachie Dazdarian
Modules: mysoft_collision.bi by Mysoft
	 24bitcustomfont.bi by Lachie D. and Chris Chadwick
                              

I. What is this?
================
This is Richard Eric Lope's pixel by pixel scrolling 
engine ported to FreeBASIC. The original engine was made 
in QBasic with RelLib by R.E.Lope in order to show the 
powers of the mentioned library. At that time (around 2002) 
I got quite interested in that engine and released a couple 
of advance versions of it, with more features and more 
comments. This FreeBASIC port is also heavily commented 
and the goal of it is to help people to create ZELDA style 
movement games in FreeBASIC of any genre (from action to RPG) 
by using GFXLib 2 graphic routines. The engine works in any 
GFXLib 2 screen mode you desire.


II. Why this engine in FreeBASIC?
=================================
After the arrival of FreeBASIC I've noticed quite 
few people (including me) having problems switching 
to FreeBASIC and finding a substitute for the code 
and coding techniques they've used in QBasic. I've 
realized that R.E.Lope's scrolling engine would be 
perfect for porting to FreeBASIC.


III. What this archive includes?
================================
This archive includes:
Very well commented source code of a pixel by 
pixel scrolling engine.
Two compiled versions of the engine (one in screen 
resolution 320*240 and one in 640*480).
Engine packed in a nice example demo (player can walk 
around a small map and collide with tiles and few moving 
characters).
Map tiles (at this point, only 20*20 pixels large) and 
sprites for character animation.

The engine features:
* pixel by pixel screen scrolling
* tiles and sprites stored in 24-bit color depth BMP images
* pixel perfect collision with moving NPCs
* tile-based collision with map tiles
* custom font printing routines
* script file with main engine parameters

What might be added in the future:
* foreground layer
* map editor
* colliding objects layer
* sliding of colliding objects feature


IV. How can I use this engine for my projects?
==============================================
Unfortunately, this is up to you. If you don't have 
any experience in game design, this engine won't help 
you in that department. It's not a game making learning 
tool. It will help you start, but you'll get stuck very 
soon.

Its main purpose is to help you grasp the concept of
scrolling maps consisted of tiles.

To change the engine resolution, tile size and the
map/graphics files, use the "engine_script1.txt" script
file.


V. Known bugs
=============
Movement of NPCs is somewhat flawed, but this is nothing
related to the nature of the engine (only to the crappy
AI).


VI. Updates
===========

13.02.2008 - Now after OVER a year I'm releasing Edition #3.
Changes? No more Pixel Plus 256 files! All graphics are now
stored in 24-bit color detph BMP images. New pixel perfect
collision, which I think works perfectly now. Better collision
with tiles. Cleaned up the code. New font printing routine.
A script file setting the main engine parameters.

31.12.2006 - After almost a year I'm releasing Edition #2 of 
the engine. Actually, there aren't many updates. I was designing 
my new site and re-archiving all my stuff so I was thinking I 
should finally alter the engine code to work FB version 0.16b, 
which is done now. Hopefully these kinds of updates won't be 
necessary anymore. Beside that. the comments were revised, the 
page flipping was improved and I added a new and better program 
speed control (in the sense of FPS).

31.01.2006 - Edition #1 fix. Some stuff with subtraction of 
two pointer operands was changed in FreeBASIC version 0.15 so 
I had to fix the GetWidth function(it's consisted only of one 
line). I kept the old line REMed so you can unREM it and REM 
the new one if you are working in FreeBASIC versions prior to 
0.15. The error caused for the custom font characters not to 
print with right spacing between them. Deallocation of memory 
allocated for PUT file graphics was added before the END 
statement since I've learned that deallocation memory allocated 
for pointers before ending a program is RECOMMENDED.

04.10.2005 - Edition #1 fixes. Fixed the problem with GetWidth 
statement. Changed the method of pixel perfect collison collision 
a bit(it's better know). Recompiled the source codes in FreeBASIC 
ver.0.14. Added a millisecond delay in the game loops to prevent 
the 100% CPU usage problem. I apologize for all the problems 
that the previous version may have caused.


VII. Feedback
=============
Please feel free to send feedback related to this engine 
of any sort. Comments, critics, additions, anything. 
I'm mostly interested in adding collision that features
"slidding-off" effect.


*** Lachie Dazdarian(lachie13@yahoo.com)
*** lachie.phatcode.net
*** games.freebasic.net

