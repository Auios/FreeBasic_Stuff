
Easy GL2D

Description:
          Easy GL2D is a very simple 2d OpenGL rendering engine.
	It is made with two simple things in mind: Speed and eas of use.
	Everything is function based so just about any programming
	design pattern can be used in conjunction with easy GL2D.
	      This started as a proof of concept 2 days ago for
	a tutorial I was making but people got interested so I
	added a few more stuff to be a complete rendering engine.
	
	Relminator(Richard Eric M. Lope) 08/19/2010
	http://rel.betterwebber.com/

	*Use this with my texture packer and it would
         be very easy to construct an engine.
         
	Texturepacker
	http://rel.betterwebber.com/junk.php?id=106
         

	
Features:

	Easy to use
	Very fast
	No dependencies except FB, OpenGL and GLU
	Able to support standard FBGFX BMPs
	OpenGL states(color, AA, blending, etc) can be applied
        to any primitive or sprite.	
	Full hardware
	
Limitations:
    Full hardware
	Author is lazy

	
	* See the demo if you like it.
Code constributions:

    Michael "h4tt3n" Nissen (Fast ellipse code)
    Landeel (Linux screensync)
	
Greetz:
    DR_D
    Lachie
    LOJ
    AAP (Most of the sprites are his)
    All the FB guys
    All the guys at DBF
    All the guys at QB64
    All the guys at Devkitpro and GBAdev



Update ver 0.5

    Fixed:
      1. pixel inconsistency in sprite rendering
      2. Filled primitive stuff discrepancy
    Added:
      Vsynch
      Ellipse
      Made a version compatible with FB.IMAGE


Update ver 0.4

Added more primitives
Glowline looks better
More sprite stretching
Many more stuff I'm too lazy to document